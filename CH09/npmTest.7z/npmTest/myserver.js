// require related modules
const http = require('http');
const fs = require('fs');
const ejs = require('ejs');
var template = fs.readFileSync(__dirname + '\\hello.ejs', 'utf-8');
const server = http.createServer((req, res) => {
    var data = ejs.render(template, {
        title: 'Hello ejs',
        content: '<H1><strong>Happy Hours with EJS!</strong></H1>'
    });
    res.setHeader('Content-Type', 'text/html');
    res.statusCode = 200;
    res.end(data);
});
const hostname = '127.0.0.1';
const port = 3030;
server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});