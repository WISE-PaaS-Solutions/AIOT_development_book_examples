// 載入Express套件
var express = require("express");
// 建立Express application實例
var app = express();
// 當使用者連線到伺服器的根目錄（/）時，做出回應。
app.get("/", function(req, res) {
     res.send("<h1> Hello Express!</h1>");
});
app.listen(3030, function(){
     console.log("Server running at localhost: http://localhost:3030/");
});