var express = require('express');
var router = express.Router();
const mongoClient = require('mongodb').MongoClient;

var url = 'mongodb://8c251d46-f357-4c60-904a-c41954eced43:uPCdWp0QfuWWig4e6gXH83r9@mongodb-eks002-pub.education.wise-paas.com:27017/BearingState';

router.get('/', function(req, res, next) {
  mongoClient.connect(url, function(err, db) {
    if (err) throw err;
    console.log("connected!!!");
 
    var dbo = db.db("BearingState");
    dbo.collection("BearingData").find({}).toArray(function(err, result) {
      if (err) throw err;
	  console.log(result);
      res.render('index', {dbContent: result});
    });
  });
});

module.exports = router;