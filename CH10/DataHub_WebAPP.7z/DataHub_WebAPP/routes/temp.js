var express = require('express');
var router = express.Router();
const Influx = require('influx');

const influx = new Influx.InfluxDB('http://481464ab-3a8d-4be0-b9c3-2e9711737863:rzpef8axkKWs7Grhs5LsgciIj@apps-influxdb-single-9dbc46d9-5aea-48ac-a976-e8ebb5c22f0b-pub.education.wise-paas.com:8086/64c9278c-05b2-49ad-b1db-895438e7fff9')

router.get('/', function (req, res, next) {
	influx.queryRaw(
		`SELECT val FROM "HistRawData_d81f358f-d490-47c0-8790-cd8af37e6dee_Device1" tz('Asia/Taipei')`
	).then(results => {
		dataArray = results.results[0].series[0].values;
		time = new Array();
		temp = new Array();
		for (var i = 0; i < dataArray.length / 2; i++) {
			time[i] = '\'' + dataArray[i * 2][0].substr(0, 19) + '\'';
			temp[i] = dataArray[i * 2][1];
		}

		res.render('temp', { timestamp: time.toString(), points: temp });
	})
});

module.exports = router;