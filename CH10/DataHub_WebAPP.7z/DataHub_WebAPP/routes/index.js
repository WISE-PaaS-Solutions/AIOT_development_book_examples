var express = require('express');
var router = express.Router();
const Influx = require('influx');

const influx = new Influx.InfluxDB('http://481464ab-3a8d-4be0-b9c3-2e9711737863:rzpef8axkKWs7Grhs5LsgciIj@apps-influxdb-single-9dbc46d9-5aea-48ac-a976-e8ebb5c22f0b-pub.education.wise-paas.com:8086/64c9278c-05b2-49ad-b1db-895438e7fff9')

router.get('/', function (req, res, next) {
	influx.queryRaw(
		`SELECT val FROM "HistRawData_d81f358f-d490-47c0-8790-cd8af37e6dee_Device1" tz('Asia/Taipei')`
	).then(results => {
		data = results.results[0].series[0].values;
		res.render('index', { dbData: data });
	})
});

module.exports = router;
