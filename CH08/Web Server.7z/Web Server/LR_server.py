# Import libraries
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
import pickle
app = Flask(__name__)
# Load the model
model = pickle.load(open('model.pickle','rb'))
@app.route('/api',methods=['POST'])
def aiot_func():
    # Get the data from the POST request.
    data = request.get_json(force=True)
    # Make prediction using model loaded from disk as per the data.
    my_array = np.array([[data['x1'],data['x2'],data['x3'],data['x4'],data['x5']]])
    df = pd.DataFrame(my_array, columns = ['Frequency','Angle','Chord length','velocity','thickness'])
    prediction = model.predict(df)
    # Take the first value of prediction
    output = prediction[0]
    return jsonify(output)
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)