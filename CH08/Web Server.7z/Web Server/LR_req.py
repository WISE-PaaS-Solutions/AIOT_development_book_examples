import requests
url = 'http://192.168.0.136:5000/api'
r = requests.post(url,json={'x1':5000, 'x2':0.0, 'x3':0.3048, 'x4':31.7, 'x5':0.003313})
print(r.json())