import pandas
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import pickle

df_train = pandas.read_csv('./df_train.csv')
x_train = df_train.drop(['sound pressure level'],axis = 1)
y_train = df_train['sound pressure level']

df_test = pandas.read_csv('./df_test.csv')
x_test = df_test.drop(['sound pressure level'],axis = 1)
y_test = df_test['sound pressure level']

mymodel = LinearRegression()
mymodel.fit(x_train,y_train)
myanswer = mymodel.predict(x_test)

print('預測值\n', myanswer )
print('正確值\n', y_test.values )
print('Mean squared error:', mean_squared_error(y_test, myanswer))
print('模型參數:', mymodel.coef_)

pickle.dump(mymodel, open('model.pickle', 'wb'))


import numpy as np

my_array = np.array([[5000,0.0,0.3048,31.7,0.003313]])

df = pandas.DataFrame(my_array, columns = ['Frequency','Angle','Chord length','velocity','thickness'])

prediction = mymodel.predict(df)
print('test:', prediction)