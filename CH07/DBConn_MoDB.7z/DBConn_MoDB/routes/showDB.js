var express = require('express');
var router = express.Router();
const mongoClient = require('mongodb').MongoClient;
var url = 'mongodb://8c251d46-f357-4c60-904a-c41954eced43:uPCdWp0QfuWWig4e6gXH83r9@mongodb-eks002-pub.education.wise-paas.com:27017/BearingState';

router.get('/', function(req, res) {
	mongoClient.connect(url, function(err, db) {
		if (err) throw err;
		console.log("connected!!!");
		
		var dbo = db.db("BearingState");
		
		dbo.collection("BearingData").find({}).sort({"Timestamp": -1}).toArray(function(err, result) {
			if (err) throw err;
			
			res.send({BearingVibration: result});
			db.close();
		});
	});
});

module.exports = router