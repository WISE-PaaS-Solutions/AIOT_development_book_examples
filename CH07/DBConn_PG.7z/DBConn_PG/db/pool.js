const Pool = require('pg').Pool
const pool = new Pool({
  user: '01cec484-8e92-418e-9c91-f1baa0e1cc17',
  host: 'apps-postgresql-single-d92afb90-6056-4fc6-ad54-787f3e02038c-pub.education.wise-paas.com',
  database: 'Vibration',
  password: 'N3FXARrymCOVnCLu7RRf0eFBc',
  port: 5432,
})

module.exports = pool;