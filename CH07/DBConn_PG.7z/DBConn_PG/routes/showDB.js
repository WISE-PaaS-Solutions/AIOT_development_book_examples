var express = require('express');
var router = express.Router();
var pool = require('../db/pool');
var moment = require('moment');

var strSQL = 'SELECT * FROM myschema.csvdata ORDER BY tid DESC';
router.get('/', function(req, res, next) {
  pool.query(strSQL, (error, results) => {  
    if (error) {
      console.log(error);
    }
    console.log(results);
     
    results.rows.map(row => {
      row.tid = moment(row.tid).format('YYYY-MM-DD HH:mm:ss');
    });
    res.send({BearingVibration: results.rows});

  })
});

module.exports = router